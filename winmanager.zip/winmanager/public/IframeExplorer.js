const ProgramIframe = `
    
    
        <iframe 
            src="https://nextjs-openai-doc-search-starter-ten-weld.vercel.app/" 
            style="border: none; width: 100%; height: 100%;"
        ></iframe>
    
   
`;
/*
exports
	.ajouterProgramme(
	"IframeExplorer", 
	{ x: 200, y: 100, width : 500, height: 350, 
	color: 'rgba(240, 240, 240, 1)', layer: 4, moveable: true, focusable:true}, 
	ProgramIframe
);*/

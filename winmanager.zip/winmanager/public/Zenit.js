
      {
        function prg_t_func_764(numThreads=0) {
          
          console.log('PID ' + numThreads);
        }
        env.addUtility('Zenit', 'prg_t_func_764', prg_t_func_764);
      }
      
      
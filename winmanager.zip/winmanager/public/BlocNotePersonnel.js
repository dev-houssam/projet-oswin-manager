
      {
        function prg_s_func_645(numThreads=0) {
          tutu.style.background = "yellow";
          console.log('PID ' + numThreads);
        }
        env.addUtility('BlocNotePersonnel', 'prg_s_func_645', prg_s_func_645);
      }
      
      
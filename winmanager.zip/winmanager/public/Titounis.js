
      {
        function prg_T_func_493(numThreads=0) {
          
          console.log('PID ' + numThreads);
        }
        env.addUtility('Titounis', 'prg_T_func_493', prg_T_func_493);
      }
      
      
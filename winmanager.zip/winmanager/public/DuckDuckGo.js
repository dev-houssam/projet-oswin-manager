
      {
        function prg_D_func_712(numThreads=0) {
          
          console.log('PID ' + numThreads);
        }
        env.addUtility('DuckDuckGo', 'prg_D_func_712', prg_D_func_712);
      }
      
      

{
  function prg_t_func_636(numThreads = 0) {
      alert(777);
      console.log('PID ' + numThreads);
  }
  env.addUtility('Gratuit', 'prg_t_func_636', prg_t_func_636);
}

{
  function prg_q_func_628(numThreads = 0) {
      alert(5);
      console.log('PID ' + numThreads);
  }
  env.addUtility('Pratique', 'prg_q_func_628', prg_q_func_628);
}
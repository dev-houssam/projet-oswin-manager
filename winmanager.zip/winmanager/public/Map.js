
      {
        function prg_M_func_305(numThreads=0) {
          
          console.log('PID ' + numThreads);
        }
        env.addUtility('Map', 'prg_M_func_305', prg_M_func_305);
      }
      
      
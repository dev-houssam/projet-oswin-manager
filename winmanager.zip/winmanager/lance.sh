#!/bin/bash

npm start &

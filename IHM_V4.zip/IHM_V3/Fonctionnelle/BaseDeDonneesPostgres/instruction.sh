#!/bin/bash

#Premierement on fait docker
docker pull postgres

#Deuxiemement on lance avec le mot de passe
docker run --name my-postgres -e POSTGRES_PASSWORD=SimpleASWater456 -p 5432:5432 -d postgres

#on rentre dans le bash pour creer un dossier
docker exec -it my-postgres bash

#puis on va creer un dossier 'winmanager' dans home
mkdir /home/winmanager


exit

#Troisiemement
docker cp ./dbwin.sql my-postgres:/home/winmanager/dbwin.sql



#On y accede
docker exec -it my-postgres psql -U postgres


########
#  CREATE DATABASE winmanager;
#
########

# acceder
# \c winmanager
# \i /home/winmanager/dbwin.sql

### dans le terminal sous VSCode lancer le serveur

npm init -y
npm install
npm start

#Pour acceder à la pge admin :

localhost:3000/_a



